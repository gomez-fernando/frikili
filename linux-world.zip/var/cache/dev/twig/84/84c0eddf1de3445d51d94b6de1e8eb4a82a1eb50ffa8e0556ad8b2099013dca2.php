<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* posts/verPost.html.twig */
class __TwigTemplate_14e586866f920d4de16dbc0aedadc5ff04f752378b70756c8e5c2d6cb2098dfd extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "posts/verPost.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "posts/verPost.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "posts/verPost.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Mis posts
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "\t";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
\t";
        // line 6
        $context["LikesDeEstePost"] = twig_split_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["post"]) || array_key_exists("post", $context) ? $context["post"] : (function () { throw new RuntimeError('Variable "post" does not exist.', 6, $this->source); })()), "likes", [], "any", false, false, false, 6), ",");
        // line 7
        echo "\t<div class=\"container bg-white rounded my-3 p-4\">
\t\t<div class=\"d-flex bd-highlight\">
\t\t\t<div class=\"p-2 flex-grow-1 bd-highlight\">
\t\t\t\t<h3>";
        // line 10
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["post"]) || array_key_exists("post", $context) ? $context["post"] : (function () { throw new RuntimeError('Variable "post" does not exist.', 10, $this->source); })()), "titulo", [], "any", false, false, false, 10), "html", null, true);
        echo "</h3>
\t\t\t\t<div class=\"my-3\" style=\"color:#3282b8;\" onclick=\"MeGusta(";
        // line 11
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["post"]) || array_key_exists("post", $context) ? $context["post"] : (function () { throw new RuntimeError('Variable "post" does not exist.', 11, $this->source); })()), "id", [], "any", false, false, false, 11), "html", null, true);
        echo ")\">
\t\t\t\t\t<i class=\"fa fa-thumbs-up\"></i>
\t\t\t\t\t<strong>
\t\t\t\t\t\t";
        // line 14
        if (twig_in_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 14, $this->source); })()), "user", [], "any", false, false, false, 14), "id", [], "any", false, false, false, 14), (isset($context["LikesDeEstePost"]) || array_key_exists("LikesDeEstePost", $context) ? $context["LikesDeEstePost"] : (function () { throw new RuntimeError('Variable "LikesDeEstePost" does not exist.', 14, $this->source); })()))) {
            // line 15
            echo "\t\t\t\t\t\t\tTe gustó esto
\t\t\t\t\t\t";
        } else {
            // line 17
            echo "\t\t\t\t\t\t\t¿Te gusta esto?
\t\t\t\t\t\t";
        }
        // line 19
        echo "\t\t\t\t\t</strong>
\t\t\t\t</div>
\t\t\t\t<div style=\"color:#c3f584;\">
\t\t\t\t\t<i class=\"far fa-clock\"></i>
\t\t\t\t\t<strong>Fecha de publicación:
\t\t\t\t\t\t";
        // line 24
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["post"]) || array_key_exists("post", $context) ? $context["post"] : (function () { throw new RuntimeError('Variable "post" does not exist.', 24, $this->source); })()), "fechapublicacion", [], "any", false, false, false, 24), "d-m-Y"), "html", null, true);
        echo "</strong>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"p-2 bd-highlight\">
\t\t\t\t<div class=\"align-self-center\">
\t\t\t\t\t<img class=\"rounded\" src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("uploads/photos/" . twig_get_attribute($this->env, $this->source, (isset($context["post"]) || array_key_exists("post", $context) ? $context["post"] : (function () { throw new RuntimeError('Variable "post" does not exist.', 29, $this->source); })()), "foto", [], "any", false, false, false, 29))), "html", null, true);
        echo "\" width=\"150px\">
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<hr>
\t\t<div class=\"text-justify my-3\">
\t\t\t";
        // line 35
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["post"]) || array_key_exists("post", $context) ? $context["post"] : (function () { throw new RuntimeError('Variable "post" does not exist.', 35, $this->source); })()), "contenido", [], "any", false, false, false, 35), "html", null, true);
        echo "
\t\t</div>
\t\t<hr>

\t</div>
\t<div class=\"container p-3\">
\t\t";
        // line 41
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 41, $this->source); })()), 'form');
        echo "
\t\t\t<h3>Comentarios</h3>
\t\t\t";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["comentarios"]) || array_key_exists("comentarios", $context) ? $context["comentarios"] : (function () { throw new RuntimeError('Variable "comentarios" does not exist.', 43, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["comentario"]) {
            // line 44
            echo "\t\t\t\t<div class=\"rounded bg-white my-2 p-3 border\">
\t\t\t\t\t<h5>";
            // line 45
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comentario"], "nombre", [], "any", false, false, false, 45), "html", null, true);
            echo "
\t\t\t\t\t\tDijo:</h5>
\t\t\t\t\t<div class=\"w-100\">";
            // line 47
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comentario"], "comentario", [], "any", false, false, false, 47), "html", null, true);
            echo "</div>
\t\t\t\t</div>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comentario'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "\t\t</div>

\t\t<div class=\"d-flex justify-content-center\">
\t\t\t<div class=\"navigation\">
\t\t\t\t";
        // line 54
        echo $this->extensions['Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension']->render($this->env, (isset($context["comentarios"]) || array_key_exists("comentarios", $context) ? $context["comentarios"] : (function () { throw new RuntimeError('Variable "comentarios" does not exist.', 54, $this->source); })()));
        echo "
\t\t\t</div>
\t\t</div>

\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 59
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 60
        echo "\t\t";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
\t\t";
        // line 64
        echo "\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "posts/verPost.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  217 => 64,  212 => 60,  202 => 59,  187 => 54,  181 => 50,  172 => 47,  167 => 45,  164 => 44,  160 => 43,  155 => 41,  146 => 35,  137 => 29,  129 => 24,  122 => 19,  118 => 17,  114 => 15,  112 => 14,  106 => 11,  102 => 10,  97 => 7,  95 => 6,  90 => 5,  80 => 4,  60 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Mis posts
{% endblock %}
{% block body %}
\t{{ parent() }}
\t{% set LikesDeEstePost = post.likes | split(',') %}
\t<div class=\"container bg-white rounded my-3 p-4\">
\t\t<div class=\"d-flex bd-highlight\">
\t\t\t<div class=\"p-2 flex-grow-1 bd-highlight\">
\t\t\t\t<h3>{{post.titulo}}</h3>
\t\t\t\t<div class=\"my-3\" style=\"color:#3282b8;\" onclick=\"MeGusta({{ post.id }})\">
\t\t\t\t\t<i class=\"fa fa-thumbs-up\"></i>
\t\t\t\t\t<strong>
\t\t\t\t\t\t{% if app.user.id in  LikesDeEstePost %}
\t\t\t\t\t\t\tTe gustó esto
\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t¿Te gusta esto?
\t\t\t\t\t\t{% endif %}
\t\t\t\t\t</strong>
\t\t\t\t</div>
\t\t\t\t<div style=\"color:#c3f584;\">
\t\t\t\t\t<i class=\"far fa-clock\"></i>
\t\t\t\t\t<strong>Fecha de publicación:
\t\t\t\t\t\t{{ post.fechapublicacion | date('d-m-Y') }}</strong>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"p-2 bd-highlight\">
\t\t\t\t<div class=\"align-self-center\">
\t\t\t\t\t<img class=\"rounded\" src=\"{{ asset('uploads/photos/'~post.foto) }}\" width=\"150px\">
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<hr>
\t\t<div class=\"text-justify my-3\">
\t\t\t{{ post.contenido }}
\t\t</div>
\t\t<hr>

\t</div>
\t<div class=\"container p-3\">
\t\t{{ form(form) }}
\t\t\t<h3>Comentarios</h3>
\t\t\t{% for comentario in comentarios %}
\t\t\t\t<div class=\"rounded bg-white my-2 p-3 border\">
\t\t\t\t\t<h5>{{ comentario.nombre }}
\t\t\t\t\t\tDijo:</h5>
\t\t\t\t\t<div class=\"w-100\">{{ comentario.comentario }}</div>
\t\t\t\t</div>
\t\t\t{% endfor %}
\t\t</div>

\t\t<div class=\"d-flex justify-content-center\">
\t\t\t<div class=\"navigation\">
\t\t\t\t{{ knp_pagination_render(comentarios) }}
\t\t\t</div>
\t\t</div>

\t{% endblock %}
\t{% block javascripts %}
\t\t{{ parent() }}
\t\t{# <script src=\"{{ asset('bundles/fosjsrouting/js/router.min.js') }}\"></script>
\t\t\t\t\t\t\t\t\t<script src=\"{{ path('fos_js_routing_js', { callback: 'fos.Router.setData' }) }}\"></script>
\t\t\t\t\t\t\t\t\t<script src=\"{{ asset('js/ajax-call.js') }}\"></script> #}
\t{% endblock %}
", "posts/verPost.html.twig", "C:\\wamp64\\www\\frikili\\templates\\posts\\verPost.html.twig");
    }
}
