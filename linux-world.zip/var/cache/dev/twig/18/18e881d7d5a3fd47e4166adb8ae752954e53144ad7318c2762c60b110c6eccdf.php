<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/index.html.twig */
class __TwigTemplate_587998a8ec2d536ffc05d40c000c72e59f0e55e5a755edd43934836b93daef00 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "dashboard/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "\t";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "\t";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
\t";
        // line 10
        echo "
\t<div class=\"container\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-8 cursor\">
\t\t\t\t";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new RuntimeError('Variable "pagination" does not exist.', 14, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 15
            echo "\t\t\t\t\t<div class=\"bg-white rounded p-3 my-3\" onclick=\"window.location.href='";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("verPost", ["id" => twig_get_attribute($this->env, $this->source, $context["post"], "id", [], "any", false, false, false, 15)]), "html", null, true);
            echo "'\">
\t\t\t\t\t\t<div class=\"d-flex bd-highlight\">
\t\t\t\t\t\t\t<div class=\"p-2 flex-grow-1 bd-highlight\">
\t\t\t\t\t\t\t\t<h3>";
            // line 18
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "titulo", [], "any", false, false, false, 18), "html", null, true);
            echo "</h3>
\t\t\t\t\t\t\t\t<div class=\"my-3 bg-yellow\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-user\"></i>
\t\t\t\t\t\t\t\t\t<strong>
\t\t\t\t\t\t\t\t\t\tCreado por
\t\t\t\t\t\t\t\t\t\t";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "nombre", [], "any", false, false, false, 23), "html", null, true);
            echo "</strong>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\" bg-green\">
\t\t\t\t\t\t\t\t\t<i class=\"far fa-clock\"></i>
\t\t\t\t\t\t\t\t\t<strong>Fecha de publicación:
\t\t\t\t\t\t\t\t\t\t";
            // line 28
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "fecha_publicacion", [], "any", false, false, false, 28), "d-m-Y"), "html", null, true);
            echo "</strong>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"p-2 bd-highlight\">
\t\t\t\t\t\t\t\t<div class=\"align-self-center\">
\t\t\t\t\t\t\t\t\t<img class=\"rounded\" src=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("uploads/photos/" . twig_get_attribute($this->env, $this->source, $context["post"], "foto", [], "any", false, false, false, 33))), "html", null, true);
            echo "\" width=\"150px\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "\t\t\t</div>
\t\t\t<div class=\"col-md-4\">
\t\t\t\t<div class=\"bg-white rounded p-3 my-3\">
\t\t\t\t\t<h4>Comentarios</h4>
\t\t\t\t\t";
        // line 48
        echo "\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<div class=\"d-flex justify-content-center\">
\t\t<div class=\"navigation\">
\t\t\t";
        // line 54
        echo $this->extensions['Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension']->render($this->env, (isset($context["pagination"]) || array_key_exists("pagination", $context) ? $context["pagination"] : (function () { throw new RuntimeError('Variable "pagination" does not exist.', 54, $this->source); })()));
        echo "
\t\t</div>
\t</div>


\t";
        // line 65
        echo "\t";
        // line 66
        echo "\t";
        // line 74
        echo "
\t";
        // line 76
        echo "\t";
        // line 85
        echo "\t";
        // line 86
        echo "\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "dashboard/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  183 => 86,  181 => 85,  179 => 76,  176 => 74,  174 => 66,  172 => 65,  164 => 54,  156 => 48,  150 => 39,  138 => 33,  130 => 28,  122 => 23,  114 => 18,  107 => 15,  103 => 14,  97 => 10,  92 => 8,  82 => 7,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}
\t{{ parent() }}
{% endblock %}

{% block body %}
\t{{ parent() }}
\t{# {{ dump(pagination) }} #}

\t<div class=\"container\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-8 cursor\">
\t\t\t\t{% for post in pagination %}
\t\t\t\t\t<div class=\"bg-white rounded p-3 my-3\" onclick=\"window.location.href='{{ path('verPost',{id:post.id}) }}'\">
\t\t\t\t\t\t<div class=\"d-flex bd-highlight\">
\t\t\t\t\t\t\t<div class=\"p-2 flex-grow-1 bd-highlight\">
\t\t\t\t\t\t\t\t<h3>{{post.titulo}}</h3>
\t\t\t\t\t\t\t\t<div class=\"my-3 bg-yellow\">
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-user\"></i>
\t\t\t\t\t\t\t\t\t<strong>
\t\t\t\t\t\t\t\t\t\tCreado por
\t\t\t\t\t\t\t\t\t\t{{post.nombre}}</strong>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\" bg-green\">
\t\t\t\t\t\t\t\t\t<i class=\"far fa-clock\"></i>
\t\t\t\t\t\t\t\t\t<strong>Fecha de publicación:
\t\t\t\t\t\t\t\t\t\t{{ post.fecha_publicacion | date('d-m-Y') }}</strong>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"p-2 bd-highlight\">
\t\t\t\t\t\t\t\t<div class=\"align-self-center\">
\t\t\t\t\t\t\t\t\t<img class=\"rounded\" src=\"{{ asset('uploads/photos/'~post.foto) }}\" width=\"150px\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t{% endfor %}
\t\t\t</div>
\t\t\t<div class=\"col-md-4\">
\t\t\t\t<div class=\"bg-white rounded p-3 my-3\">
\t\t\t\t\t<h4>Comentarios</h4>
\t\t\t\t\t{# {% for comentario in comentarios %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"bg-white my-2\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('verPost',{id:comentario.id}) }}\">{{ comentario.titulo }}</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% endfor %} #}
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<div class=\"d-flex justify-content-center\">
\t\t<div class=\"navigation\">
\t\t\t{{ knp_pagination_render(pagination) }}
\t\t</div>
\t</div>


\t{# total items count #}
{# <div class=\"count\">
\t\t\t\t\t\t\t\t{{ pagination.getTotalItemCount }}
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<table>
\t\t\t\t\t\t\t\t\t\t<tr> #}
\t{# sorting of properties based on query components #}
\t{# <th>{{ knp_pagination_sortable(pagination, 'Id', 'a.id') }}</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th {% if pagination.isSorted('a.Title') %} class=\"sorted\" {% endif %}>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{{ knp_pagination_sortable(pagination, 'Title', 'a.title') }}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th {% if pagination.isSorted(['a.date', 'a.time']) %} class=\"sorted\" {% endif %}>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{{ knp_pagination_sortable(pagination, 'Release', ['a.date', 'a.time']) }}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t</tr> #}

\t{# table body #}
\t{# {% for article in pagination %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr {% if loop.index is odd %} class=\"color\" {% endif %}>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td>{{ article.id }}</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td>{{ article.titulo }}</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td>{{ article.foto }}</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td>{{ article.fecha_publicacion | date('d-m-Y') }}</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t\t\t\t</table> #}
\t{# display navigation #}
\t{# <div class=\"navigation\">
\t\t\t\t\t\t\t\t\t\t\t\t\t{{ knp_pagination_render(pagination) }}
\t\t\t\t\t\t\t\t\t\t\t\t</div> #}
{% endblock %}
", "dashboard/index.html.twig", "C:\\wamp64\\www\\frikili\\templates\\dashboard\\index.html.twig");
    }
}
